try { require.resolve('@img/sharp-libvips-linux-x64/stub'); } catch {}
module.exports = require('./lib/sharp-linux-x64-0.35.2.node');